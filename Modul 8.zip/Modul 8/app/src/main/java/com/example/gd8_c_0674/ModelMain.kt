package com.example.gd8_c_0674

class ModelMain {
    lateinit var strName: String
    lateinit var strVicinity: String
    var latLoc = 0.0
    var longLoc = 0.0
}